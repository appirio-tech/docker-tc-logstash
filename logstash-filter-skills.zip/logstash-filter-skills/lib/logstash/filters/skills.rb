# encoding: utf-8
require "logstash/filters/base"
require "logstash/namespace"
require "redis"

# This example filter will replace the contents of the default 
# message field with whatever you specify in the configuration.
#
# It is only intended to be used as an example.
class LogStash::Filters::Example < LogStash::Filters::Base

  # Setting the config_name here is required. This is how you
  # configure this filter from your Logstash config.
  #
  # filter {
  #   example {
  #     message => "My message..."
  #   }
  # }
  #
  config_name "skills"
  
  # Replace the message with this value.
  config :message, :validate => :string, :default => "Hello World!"
  
  config :source, :redis_host, :validate => :string

  config :is_array, :validate => :boolean, :default => false 

  JSONPARSEFAILURE_TAG = "_jsonparsefailure"

  public
  def register
    # Add instance variables 
  end # def register

  public
  def filter(event)
    
    @logger.debug? && @logger.debug("Running json filter", :event => event)

    source = event[@source]
    return unless source

    redis_host = event[@redis_host]
    return unless redis_host

    begin
      parsed = LogStash::Json.load(source)
    rescue => e
      event.tag(JSONPARSEFAILURE_TAG)
      @logger.warn("Error parsing json", :source => @source, :raw => source, :exception => e)
      return
    end
   
    redis = Redis.new(:host => @redis_host, :port => 6379)

    if @is_array
      skills = Array.new
      puts "Inside our custom block"
      parsed.each{|k, v|
        skill = Hash.new
        skill["id"] = k
        skill["score"] = v["score"].to_i
        skill["sources"] = v["sources"]

        key = "tags:" + k
        if redis.exists(key)
          tmp = redis.lindex(key, 0)
          if tmp
            parsed_tmp = LogStash::Json.load(tmp)
            skill["name"] = parsed_tmp["name"]
            if parsed_tmp["synonyms"]
              skill["synonyms"] = parsed_tmp["synonyms"]
            end
          end
        end
        skills.push(skill)
      }
      event["skills"] = skills
    end

#    if @message
      # Replace the event message with our message as configured in the
      # config file.
#      event["message"] = @message
#    end

    # filter_matched should go in the last line of our successful code
    filter_matched(event)
  end # def filter
end # class LogStash::Filters::Example
