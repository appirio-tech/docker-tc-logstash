# logstash-filter-skills
Skills filter plugin. This should help bootstrap your effort to write your own filter plugin!
