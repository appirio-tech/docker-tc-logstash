require "logstash/filters/base"
require "logstash/namespace"
require "redis"
redis = Redis.new(:host => "tags-001.056cmt.0001.use1.cache.amazonaws.com", :port => 6379)

redis.set("mykey", "hello world")
#puts redis.get("mykey")

source="{\"337\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"402\":{\"score\":4.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"403\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"349\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"401\":{\"score\":28.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"130\":{\"score\":3.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"347\":{\"score\":4.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"132\":{\"score\":106.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"395\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"394\":{\"score\":3.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"155\":{\"score\":2.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"263\":{\"score\":2.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"260\":{\"score\":4.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"397\":{\"score\":3.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"334\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"212\":{\"score\":6.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"387\":{\"score\":13.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"214\":{\"score\":5.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"390\":{\"score\":20.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"102\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"170\":{\"score\":4.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"372\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"100\":{\"score\":156.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"374\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"101\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"167\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"316\":{\"score\":2.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"319\":{\"score\":2.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"104\":{\"score\":6.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"164\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"356\":{\"score\":4.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"253\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"250\":{\"score\":9.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"353\":{\"score\":2.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"248\":{\"score\":4.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"249\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"295\":{\"score\":7.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"364\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"247\":{\"score\":59.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"244\":{\"score\":4.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"245\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"360\":{\"score\":1.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"300\":{\"score\":1.0,\"sources\":[\"USER_ENTERED\"],\"hidden\":false},\"361\":{\"score\":2.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"121\":{\"score\":12.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false},\"181\":{\"score\":3.0,\"sources\":[\"CHALLENGE\"],\"hidden\":false}}"

parsed = LogStash::Json.load(source)
redis = Redis.new(:host => "127.0.0.1", :port => 6379)

skills = Array.new
parsed.each{|k, v|
skill = Hash.new
skill["id"] = k
skill["score"] = v["score"].to_i
skill["sources"] = v["sources"]
if redis.exists(k)
  tmp = redis.lindex(k, 0)
  if tmp
    parsed_tmp = LogStash::Json.load(tmp)
    skill["name"] = parsed_tmp["name"]
    if parsed_tmp["synonyms"]
      skill["synonyms"] = LogStash::Json.load(parsed_tmp["synonyms"])
    end
  end
end
skills.push(skill)
}
puts skills
